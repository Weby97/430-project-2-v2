function Music() {
    
    return (
      <footer id="music">
          <p>© 2021 Brandon Ly</p>
      </footer>
    );
}