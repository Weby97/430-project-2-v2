class SuggestWindow extends React.Component {
    render() {
        return (
            <main>
                <h1>Suggest a Song!</h1>
                <h2>Got a song you wanna listen to while you read and write? Send a suggestion!</h2>
            </main>
        );
    }
    
}