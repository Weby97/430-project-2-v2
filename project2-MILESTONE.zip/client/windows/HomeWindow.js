class HomeWindow extends React.Component {
    render() {
        return (
            <main>
                <h1>Welcome to Lofi Messages!</h1>
                <h2>Help spread some positivity!</h2>
                
            </main>
            
        );
    }
    
}